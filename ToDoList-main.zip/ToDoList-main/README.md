# ToDoList

Para rodar o código, abra o arquivo sql presente na pasta MySQL e crie as respectivas tabelas.
Após isso, altere o valor DB_PASS presente no arquivo "/variaveis.env" pela sua própria senha sql.

Em seguida, basta colocar http://localhost:3000/api/ na url do navegador.
